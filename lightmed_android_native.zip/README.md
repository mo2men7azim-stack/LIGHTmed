# LIGHTmed — Native Android App (Kotlin + Jetpack Compose)

This is a **true native Android Studio project** (Material 3 + Jetpack Compose) bundling all **2,457 Internal Medicine MCQs** and **Normal Lab Ranges** offline in `app/src/main/assets/`.

## Option 1: Build the APK Without a PC (GitHub Actions)
1. Create a free repository on **github.com** and upload the contents of this ZIP.
2. Open the **Actions** tab in your GitHub repository — **Build LIGHTmed Native APK** will run automatically (or tap **Run workflow**).
3. Once it finishes (~2 minutes), tap the completed run and download **LIGHTmed-native-apk** (`app-debug.apk`) straight to your Android phone.

## Option 2: Build in Android Studio (PC/Mac)
1. Extract this ZIP into a clean folder (e.g., `C:\AndroidProjects\LIGHTmed\` or `~/AndroidProjects/LIGHTmed/`).
2. *(Optional for live Google Sign-In & Firestore Sync)*: Download `google-services.json` for package `app.netlify.lightmed.twa` from Firebase Console (`lightmed-b1747`) and place it in `app/google-services.json`.
3. Open the folder in **Android Studio** and click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
