# Keep Gson models
-keep class app.netlify.lightmed.twa.model.** { *; }
