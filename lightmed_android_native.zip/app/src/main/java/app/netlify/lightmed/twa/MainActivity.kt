package app.netlify.lightmed.twa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import app.netlify.lightmed.twa.audio.SoundEffects
import app.netlify.lightmed.twa.data.McqRepository
import app.netlify.lightmed.twa.ui.*
import app.netlify.lightmed.twa.ui.theme.LIGHTmedTheme
import app.netlify.lightmed.twa.ui.theme.SlateBg
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = McqRepository(applicationContext)
        val sound = SoundEffects(repo.soundEnabled)

        setContent {
            LIGHTmedTheme {
                var screen by remember { mutableStateOf(AppScreen.HOME) }
                var soundOn by remember { mutableStateOf(repo.soundEnabled) }
                var userEmail by remember { mutableStateOf(repo.currentEmail()) }
                var userUid by remember { mutableStateOf(repo.currentUid()) }
                var progress by remember { mutableStateOf<Map<String, Boolean>>(repo.loadProgress(userUid)) }
                var showSyncDialog by remember { mutableStateOf(false) }
                var syncStatus by remember { mutableStateOf<String?>(null) }

                val googleSignInLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    try {
                        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                        val account = task.getResult(ApiException::class.java)
                        val cred = GoogleAuthProvider.getCredential(account.idToken, null)
                        FirebaseAuth.getInstance().signInWithCredential(cred)
                            .addOnSuccessListener { authRes ->
                                val u = authRes.user
                                userUid = u?.uid
                                userEmail = u?.email
                                if (u != null) {
                                    progress = repo.mergeGuestIntoUser(u.uid, u.email)
                                    repo.syncWithFirestore(progress) { ok, merged, msg ->
                                        progress = merged
                                        syncStatus = msg
                                    }
                                }
                            }
                            .addOnFailureListener { e ->
                                syncStatus = e.message ?: "Firebase sign-in failed."
                            }
                    } catch (e: Throwable) {
                        syncStatus = e.message ?: "Google Sign-In cancelled."
                    }
                }

                Surface(modifier = Modifier.fillMaxSize(), color = SlateBg) {
                    Column(Modifier.fillMaxSize()) {
                        TopHeader(
                            soundEnabled = soundOn,
                            userEmail = userEmail,
                            onToggleSound = {
                                soundOn = !soundOn
                                repo.soundEnabled = soundOn
                                sound.enabled = soundOn
                                if (soundOn) sound.playMenu()
                            },
                            onOpenHome = {
                                sound.playMenu()
                                screen = AppScreen.HOME
                            },
                            onOpenSync = {
                                sound.playMenu()
                                showSyncDialog = true
                            }
                        )

                        Box(Modifier.weight(1f)) {
                            val stats = remember(progress) { repo.computeStats(progress) }
                            when (screen) {
                                AppScreen.HOME -> HomeScreen(
                                    totalQuestions = repo.questions.size,
                                    overallStats = stats.first(),
                                    userEmail = userEmail,
                                    onStartQuiz = { sound.playMenu(); screen = AppScreen.QUIZ },
                                    onOpenScoreboard = { sound.playMenu(); screen = AppScreen.SCOREBOARD },
                                    onOpenReference = { sound.playMenu(); screen = AppScreen.REFERENCE },
                                    onOpenSync = { sound.playMenu(); showSyncDialog = true }
                                )
                                AppScreen.QUIZ -> QuizScreen(
                                    allQuestions = repo.questions,
                                    topics = repo.topics,
                                    progress = progress,
                                    onAnswerRecorded = { q, isCorrect ->
                                        if (isCorrect) sound.playCorrect() else sound.playIncorrect()
                                        val updated = progress.toMutableMap()
                                        updated[q.key] = isCorrect
                                        progress = updated
                                        repo.saveProgress(updated, userUid, userEmail)
                                    },
                                    onBack = { sound.playMenu(); screen = AppScreen.HOME }
                                )
                                AppScreen.SCOREBOARD -> ScoreboardScreen(
                                    stats = stats,
                                    onReset = {
                                        progress = emptyMap()
                                        repo.saveProgress(emptyMap(), userUid, userEmail)
                                    },
                                    onBack = { sound.playMenu(); screen = AppScreen.HOME }
                                )
                                AppScreen.REFERENCE -> ReferenceScreen(
                                    labSystems = repo.labSystems,
                                    onBack = { sound.playMenu(); screen = AppScreen.HOME }
                                )
                            }
                        }
                    }

                    if (showSyncDialog) {
                        SyncDialog(
                            userEmail = userEmail,
                            statusMessage = syncStatus,
                            firebaseReady = repo.isFirebaseReady(),
                            onSignInGoogle = {
                                if (repo.isFirebaseReady()) {
                                    val webClientIdRes = resources.getIdentifier("default_web_client_id", "string", packageName)
                                    val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail()
                                    if (webClientIdRes != 0) builder.requestIdToken(getString(webClientIdRes))
                                    val client = GoogleSignIn.getClient(this@MainActivity, builder.build())
                                    googleSignInLauncher.launch(client.signInIntent)
                                }
                            },
                            onSyncNow = {
                                repo.syncWithFirestore(progress) { _, merged, msg ->
                                    progress = merged
                                    syncStatus = msg
                                }
                            },
                            onSignOut = {
                                if (repo.isFirebaseReady()) FirebaseAuth.getInstance().signOut()
                                userUid = null
                                userEmail = null
                                progress = repo.loadProgress(null)
                                syncStatus = "Signed out."
                            },
                            onDismiss = { showSyncDialog = false }
                        )
                    }
                }
            }
        }
    }
}
