package app.netlify.lightmed.twa.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class SoundEffects(var enabled: Boolean = true) {

    fun playMenu() {
        if (!enabled) return
        playTone(580.0, 65)
    }

    fun playCorrect() {
        if (!enabled) return
        Thread {
            playToneSync(523.25, 80)
            playToneSync(659.25, 80)
            playToneSync(783.99, 130)
        }.start()
    }

    fun playIncorrect() {
        if (!enabled) return
        Thread {
            playToneSync(260.0, 120)
            playToneSync(196.0, 170)
        }.start()
    }

    private fun playTone(freqHz: Double, durationMs: Int) {
        Thread { playToneSync(freqHz, durationMs) }.start()
    }

    private fun playToneSync(freqHz: Double, durationMs: Int) {
        try {
            val sampleRate = 22050
            val count = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(count)
            for (i in 0 until count) {
                val env = exp(-3.5 * i / count)
                val sample = sin(2.0 * PI * i * freqHz / sampleRate) * env
                buffer[i] = (sample * Short.MAX_VALUE * 0.25).toInt().toShort()
            }
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(buffer, 0, buffer.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 15)
            track.release()
        } catch (_: Throwable) {
        }
    }
}
