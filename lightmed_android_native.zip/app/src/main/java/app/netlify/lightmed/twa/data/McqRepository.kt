package app.netlify.lightmed.twa.data

import android.content.Context
import app.netlify.lightmed.twa.model.LabSystem
import app.netlify.lightmed.twa.model.McqQuestion
import app.netlify.lightmed.twa.model.TopicStats
import app.netlify.lightmed.twa.model.UserIdGenerator
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class McqRepository(private val context: Context) {

    private val gson = Gson()
    private val prefs = context.getSharedPreferences("lightmed_prefs", Context.MODE_PRIVATE)

    val questions: List<McqQuestion> by lazy {
        val json = context.assets.open("mcqs.json").bufferedReader().use { it.readText() }
        val type = object : TypeToken<List<McqQuestion>>() {}.type
        gson.fromJson(json, type) ?: emptyList()
    }

    val labSystems: List<LabSystem> by lazy {
        val json = context.assets.open("lab_ranges.json").bufferedReader().use { it.readText() }
        val type = object : TypeToken<List<LabSystem>>() {}.type
        gson.fromJson(json, type) ?: emptyList()
    }

    val topics: List<String> by lazy {
        listOf("All Topics") + questions.map { it.topic }.distinct().sorted()
    }

    var soundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", true)
        set(value) { prefs.edit().putBoolean("sound_enabled", value).apply() }

    private fun progressKey(uid: String?): String {
        val clean = (uid ?: "guest").trim().lowercase()
        return "progress_$clean"
    }

    fun loadProgress(uid: String? = currentUid()): MutableMap<String, Boolean> {
        val raw = prefs.getString(progressKey(uid), null) ?: return mutableMapOf()
        return try {
            val type = object : TypeToken<MutableMap<String, Boolean>>() {}.type
            gson.fromJson(raw, type) ?: mutableMapOf()
        } catch (_: Throwable) {
            mutableMapOf()
        }
    }

    fun saveProgress(progress: Map<String, Boolean>, uid: String? = currentUid(), email: String? = currentEmail()) {
        prefs.edit().putString(progressKey(uid), gson.toJson(progress)).apply()
        if (!uid.isNullOrBlank() && isFirebaseReady()) {
            try {
                val db = FirebaseFirestore.getInstance()
                val payload = hashMapOf(
                    "email" to (email ?: ""),
                    "lightmedUserId" to UserIdGenerator.fromEmail(email),
                    "progressResults" to progress,
                    "updatedAt" to java.time.Instant.now().toString()
                )
                db.collection("users").document(uid).set(payload, SetOptions.merge())
            } catch (_: Throwable) {
            }
        }
    }

    fun mergeGuestIntoUser(uid: String, email: String?): MutableMap<String, Boolean> {
        val guest = loadProgress("guest")
        val user = loadProgress(uid)
        val merged = LinkedHashMap<String, Boolean>(guest)
        merged.putAll(user)
        saveProgress(merged, uid, email)
        return merged
    }

    fun computeStats(progress: Map<String, Boolean>): List<TopicStats> {
        return topics.map { t ->
            val list = if (t == "All Topics") questions else questions.filter { it.topic == t }
            var attempted = 0
            var correct = 0
            for (q in list) {
                val res = progress[q.key]
                if (res != null) {
                    attempted++
                    if (res) correct++
                }
            }
            TopicStats(topic = t, total = list.size, attempted = attempted, correct = correct)
        }
    }

    fun isFirebaseReady(): Boolean = FirebaseApp.getApps(context).isNotEmpty()

    fun currentUid(): String? = if (isFirebaseReady()) FirebaseAuth.getInstance().currentUser?.uid else null

    fun currentEmail(): String? = if (isFirebaseReady()) FirebaseAuth.getInstance().currentUser?.email else null

    fun syncWithFirestore(
        localProgress: Map<String, Boolean>,
        onComplete: (Boolean, Map<String, Boolean>, String) -> Unit
    ) {
        val uid = currentUid()
        val email = currentEmail()
        if (uid == null || !isFirebaseReady()) {
            onComplete(false, localProgress, "Not signed in or google-services.json missing.")
            return
        }
        val db = FirebaseFirestore.getInstance()
        db.collection("users").document(uid).get()
            .addOnSuccessListener { snap ->
                val remoteRaw = snap.get("progressResults") as? Map<*, *>
                val merged = LinkedHashMap<String, Boolean>()
                remoteRaw?.forEach { (k, v) ->
                    if (k is String && v is Boolean) merged[k] = v
                }
                merged.putAll(localProgress)
                saveProgress(merged, uid, email)
                onComplete(true, merged, "Cloud scores synced!")
            }
            .addOnFailureListener { err ->
                onComplete(false, localProgress, err.message ?: "Firestore sync failed.")
            }
    }
}
