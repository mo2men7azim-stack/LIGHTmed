package app.netlify.lightmed.twa.model

data class McqQuestion(
    val topic: String,
    val stem: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String = "",
    val sourceLabel: String = ""
) {
    val key: String
        get() = "$topic::${stem.take(80)}"
}

data class LabItem(
    val name: String,
    val range: String
)

data class LabSystem(
    val system: String,
    val items: List<LabItem>
)

data class TopicStats(
    val topic: String,
    val total: Int,
    val attempted: Int,
    val correct: Int
) {
    val accuracyPct: Int
        get() = if (attempted == 0) 0 else ((correct * 100.0) / attempted).toInt()
}

object UserIdGenerator {
    /**
     * Generates the same deterministic LM-XXXXXXXX ID for an email as the web app.
     */
    fun fromEmail(email: String?): String {
        val clean = (email ?: "").trim().lowercase()
        if (clean.isEmpty()) return ""
        var h1 = 0x811c9dc5.toInt()
        var h2 = 0x9e3779b9.toInt()
        for (i in clean.indices) {
            val ch = clean[i].code
            h1 = (h1 xor ch) * 0x01000193
            h2 = (h2 xor (ch + i)) * 0x85ebca6b.toInt()
        }
        val part1 = (h1.toUInt()).toString(16).uppercase().padStart(8, '0').take(4)
        val part2 = (h2.toUInt()).toString(16).uppercase().padStart(8, '0').take(4)
        return "LM-$part1$part2"
    }
}
