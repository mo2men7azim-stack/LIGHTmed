package app.netlify.lightmed.twa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.netlify.lightmed.twa.model.LabSystem
import app.netlify.lightmed.twa.model.McqQuestion
import app.netlify.lightmed.twa.model.TopicStats
import app.netlify.lightmed.twa.model.UserIdGenerator
import app.netlify.lightmed.twa.ui.theme.EmeraldSuccess
import app.netlify.lightmed.twa.ui.theme.IndigoPrimary
import app.netlify.lightmed.twa.ui.theme.RoseError
import app.netlify.lightmed.twa.ui.theme.TealAccent

enum class AppScreen { HOME, QUIZ, SCOREBOARD, REFERENCE }

@Composable
fun TopHeader(
    soundEnabled: Boolean,
    userEmail: String?,
    onToggleSound: () -> Unit,
    onOpenHome: () -> Unit,
    onOpenSync: () -> Unit
) {
    val userId = remember(userEmail) { UserIdGenerator.fromEmail(userEmail) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(IndigoPrimary, TealAccent)))
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text("LIGHTmed", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(
            "Internal Medicine MCQs • By DR momin hazim ibrahim ahmed",
            color = Color.White.copy(alpha = 0.88f),
            fontSize = 12.sp
        )
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeaderChip("Main Menu", Icons.Default.Home, onOpenHome)
            HeaderChip(
                if (soundEnabled) "Sound: On" else "Sound: Off",
                if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                onToggleSound
            )
            HeaderChip(
                if (!userEmail.isNullOrBlank()) "$userEmail ($userId)" else "Google Sign-In",
                Icons.Default.AccountCircle,
                onOpenSync
            )
        }
    }
}

@Composable
private fun HeaderChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun HomeScreen(
    totalQuestions: Int,
    overallStats: TopicStats,
    userEmail: String?,
    onStartQuiz: () -> Unit,
    onOpenScoreboard: () -> Unit,
    onOpenReference: () -> Unit,
    onOpenSync: () -> Unit
) {
    val userId = remember(userEmail) { UserIdGenerator.fromEmail(userEmail) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Welcome to LIGHTmed", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "$totalQuestions verified Internal Medicine MCQs across 12 specialties, stored natively offline.",
                    fontSize = 13.sp,
                    color = Color(0xFF475569)
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Overall Score: ${overallStats.correct} / ${overallStats.attempted} (${overallStats.accuracyPct}%)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = IndigoPrimary
                )
            }
        }

        MenuActionCard(
            title = "Practice MCQs",
            subtitle = "Filter by 12 specialties, shuffle, jump to any #, and read instant explanations.",
            gradient = listOf(IndigoPrimary, Color(0xFF3730A3)),
            onClick = onStartQuiz
        )
        MenuActionCard(
            title = "Scoreboard & Progress",
            subtitle = "Track accuracy per specialty across all $totalQuestions questions.",
            gradient = listOf(TealAccent, Color(0xFF0F766E)),
            onClick = onOpenScoreboard
        )
        MenuActionCard(
            title = "Normal Lab Ranges",
            subtitle = "Quick clinical reference organized by Internal Medicine system.",
            gradient = listOf(Color(0xFF0284C7), Color(0xFF0369A1)),
            onClick = onOpenReference
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(18.dp))
                .clickable(onClick = onOpenSync)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Google Sign-In & Cloud Sync", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (!userEmail.isNullOrBlank())
                        "Signed in as $userEmail (ID: $userId)"
                    else
                        "Sign in with Google to get your unique LIGHTmed ID and sync scores across phones.",
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )
            }
        }
    }
}

@Composable
private fun MenuActionCard(
    title: String,
    subtitle: String,
    gradient: List<Color>,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(gradient))
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Column {
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
        }
    }
}

@Composable
fun QuizScreen(
    allQuestions: List<McqQuestion>,
    topics: List<String>,
    progress: Map<String, Boolean>,
    onAnswerRecorded: (McqQuestion, Boolean) -> Unit,
    onBack: () -> Unit
) {
    var selectedTopic by remember { mutableStateOf("All Topics") }
    var shuffled by remember { mutableStateOf(false) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var jumpText by remember { mutableStateOf("") }

    val filteredQuestions = remember(allQuestions, selectedTopic, shuffled) {
        val base = if (selectedTopic == "All Topics") allQuestions else allQuestions.filter { it.topic == selectedTopic }
        if (shuffled) base.shuffled() else base
    }

    LaunchedEffect(selectedTopic, shuffled) {
        currentIndex = 0
        selectedOption = null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = onBack, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Menu", fontSize = 12.sp)
            }
            Text(
                "Question ${if (filteredQuestions.isEmpty()) 0 else currentIndex + 1} of ${filteredQuestions.size}",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = IndigoPrimary
            )
        }

        // Topic Filter Pills
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            topics.forEach { t ->
                val active = t == selectedTopic
                FilterChip(
                    selected = active,
                    onClick = { selectedTopic = t },
                    label = { Text(t, fontSize = 12.sp) }
                )
            }
        }

        // Shuffle + Jump Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = shuffled,
                onClick = { shuffled = !shuffled },
                label = { Text(if (shuffled) "Shuffle: On" else "Shuffle: Off", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            OutlinedTextField(
                value = jumpText,
                onValueChange = { jumpText = it.filter { ch -> ch.isDigit() } },
                placeholder = { Text("Go to #", fontSize = 12.sp) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f).height(48.dp),
                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
            )
            Button(
                onClick = {
                    val n = jumpText.toIntOrNull()
                    if (n != null && n in 1..filteredQuestions.size) {
                        currentIndex = n - 1
                        selectedOption = null
                        jumpText = ""
                    }
                }
            ) {
                Text("Go", fontSize = 12.sp)
            }
        }

        if (filteredQuestions.isNotEmpty()) {
            val q = filteredQuestions[currentIndex.coerceIn(0, filteredQuestions.lastIndex)]
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AssistChip(
                        onClick = {},
                        label = { Text(q.topic, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Text(q.stem, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 22.sp)

                    val letters = listOf("A", "B", "C", "D", "E")
                    q.options.forEachIndexed { idx, opt ->
                        val answered = selectedOption != null
                        val isCorrect = idx == q.correctIndex
                        val isPicked = idx == selectedOption
                        val bgColor = when {
                            !answered -> Color(0xFFF8FAFC)
                            isCorrect -> Color(0xFFECFDF5)
                            isPicked -> Color(0xFFFFF1F2)
                            else -> Color(0xFFF8FAFC)
                        }
                        val borderColor = when {
                            !answered -> Color(0xFFE2E8F0)
                            isCorrect -> EmeraldSuccess
                            isPicked -> RoseError
                            else -> Color(0xFFE2E8F0)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(bgColor)
                                .border(1.5.dp, borderColor, RoundedCornerShape(12.dp))
                                .clickable(enabled = !answered) {
                                    selectedOption = idx
                                    onAnswerRecorded(q, idx == q.correctIndex)
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(letters.getOrElse(idx) { "${idx + 1}" }, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Text(opt, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        }
                    }

                    if (selectedOption != null) {
                        val wasRight = selectedOption == q.correctIndex
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (wasRight) Color(0xFFECFDF5) else Color(0xFFFFF1F2)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    if (wasRight) "Correct!" else "Incorrect",
                                    fontWeight = FontWeight.Bold,
                                    color = if (wasRight) EmeraldSuccess else RoseError
                                )
                                if (q.explanation.isNotBlank()) {
                                    Text(q.explanation, fontSize = 13.sp, color = Color(0xFF334155))
                                }
                                if (q.sourceLabel.isNotBlank()) {
                                    Text("Source: ${q.sourceLabel}", fontSize = 11.sp, color = IndigoPrimary)
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedButton(
                            enabled = currentIndex > 0,
                            onClick = {
                                currentIndex--
                                selectedOption = null
                            }
                        ) {
                            Text("Previous")
                        }
                        Button(
                            enabled = currentIndex < filteredQuestions.lastIndex,
                            onClick = {
                                currentIndex++
                                selectedOption = null
                            }
                        ) {
                            Text("Next Question")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScoreboardScreen(
    stats: List<TopicStats>,
    onReset: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = onBack) { Text("← Menu") }
            Text("Scoreboard", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onReset) { Text("Reset", color = RoseError) }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(stats) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(s.topic, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${s.correct}/${s.attempted} (${s.accuracyPct}%)", fontWeight = FontWeight.Bold, color = IndigoPrimary, fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { if (s.total == 0) 0f else s.attempted.toFloat() / s.total.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("${s.attempted} of ${s.total} answered", fontSize = 11.sp, color = Color(0xFF64748B))
                    }
                }
            }
        }
    }
}

@Composable
fun ReferenceScreen(
    labSystems: List<LabSystem>,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onBack) { Text("← Menu") }
            Text("Normal Lab Ranges", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search lab test or system...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val qLower = query.trim().lowercase()
            val filtered = labSystems.mapNotNull { sys ->
                val items = if (qLower.isEmpty()) sys.items else sys.items.filter {
                    it.name.lowercase().contains(qLower) || it.range.lowercase().contains(qLower) || sys.system.lowercase().contains(qLower)
                }
                if (items.isEmpty()) null else sys.copy(items = items)
            }
            items(filtered) { sys ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(sys.system, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = IndigoPrimary)
                        sys.items.forEach { item ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                Text(item.range, fontSize = 12.sp, color = Color(0xFF475569))
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SyncDialog(
    userEmail: String?,
    statusMessage: String?,
    firebaseReady: Boolean,
    onSignInGoogle: () -> Unit,
    onSyncNow: () -> Unit,
    onSignOut: () -> Unit,
    onDismiss: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val userId = remember(userEmail) { UserIdGenerator.fromEmail(userEmail) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Google Sign-In & Cloud Sync", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!userEmail.isNullOrBlank()) {
                    Text("Signed in as $userEmail", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFEEF2FF))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ID: $userId", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                        TextButton(onClick = { clipboard.setText(AnnotatedString(userId)) }) {
                            Text("Copy ID", fontSize = 12.sp)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onSyncNow) { Text("Sync Now") }
                        OutlinedButton(onClick = onSignOut) { Text("Sign Out") }
                    }
                } else {
                    Text(
                        if (firebaseReady)
                            "Sign in with Google to sync your MCQ progress and get your unique LIGHTmed ID."
                        else
                            "Offline mode active. Add google-services.json to app/ and rebuild to enable live Google Sign-In.",
                        fontSize = 13.sp
                    )
                    Button(onClick = onSignInGoogle, enabled = firebaseReady) {
                        Text("Sign in with Google")
                    }
                }
                if (!statusMessage.isNullOrBlank()) {
                    Text(statusMessage, fontSize = 12.sp, color = IndigoPrimary)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
