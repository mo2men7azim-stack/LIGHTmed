package app.netlify.lightmed.twa.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF4F46E5)
val TealAccent = Color(0xFF0D9488)
val EmeraldSuccess = Color(0xFF059669)
val RoseError = Color(0xFFE11D48)
val SlateBg = Color(0xFFF8FAFC)

private val LightColors = lightColorScheme(
    primary = IndigoPrimary,
    secondary = TealAccent,
    background = SlateBg,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)

@Composable
fun LIGHTmedTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
